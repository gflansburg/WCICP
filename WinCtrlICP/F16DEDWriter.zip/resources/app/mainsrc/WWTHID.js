const WWTHID_JSAPI = require('../WWTHID_JSAPI');

module.exports.WWTHID_JSAPI = WWTHID_JSAPI;
